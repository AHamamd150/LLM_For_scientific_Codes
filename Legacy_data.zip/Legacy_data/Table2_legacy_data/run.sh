python summarize_helper_selection_historical.py \
  qwen14B \
  --label qwen14B \
  --out helper_summary_qwen14B
python summarize_helper_selection_historical.py \
  llama70B \
  --label llama70B \
  --out helper_summary_llama70B
