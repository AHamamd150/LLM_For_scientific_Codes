#!/usr/bin/env python3
"""
Summarize helper-selection stability from the historical dataset format:

  MODEL/
    case_1/
      1
      2
      ...
    case_2/
      1
      ...

Each run file is a full task card containing an [ADDITIONAL_HELPERS] section.

The input may be either:
  * an unpacked dataset directory, or
  * a .zip archive containing that directory.

Outputs:
  * summary.txt                 human-readable occurrence summary by case
  * helper_stability.csv        one row per case
  * helper_frequencies.csv      one row per helper per case
  * pairwise_jaccard.csv        every run-pair Jaccard value

Only Python standard library is used.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import re
import statistics
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Set, Tuple


CASE_RE = re.compile(r"(?:^|/)case_(\d+)(?:/|$)")
RUN_RE = re.compile(r"(?:^|/)case_\d+/(\d+)$")
SECTION_RE = re.compile(r"^\[ADDITIONAL_HELPERS\]\s*$", re.MULTILINE)


def parse_helpers(text: str, source: str) -> Set[str]:
    m = SECTION_RE.search(text)
    if not m:
        raise ValueError(f"{source}: [ADDITIONAL_HELPERS] section not found")

    helpers: Set[str] = set()
    for line in text[m.end():].splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("[") and s.endswith("]"):
            break
        if s.startswith("-"):
            name = s[1:].strip()
            if name:
                helpers.add(name)
    helpers.discard("read_lhco")
    return helpers


def load_from_directory(root: Path) -> Dict[Tuple[int, int], Set[str]]:
    records: Dict[Tuple[int, int], Set[str]] = {}
    for case_dir in sorted(root.rglob("case_*")):
        if not case_dir.is_dir():
            continue
        m = re.fullmatch(r"case_(\d+)", case_dir.name)
        if not m:
            continue
        case = int(m.group(1))
        for f in sorted(case_dir.iterdir()):
            if not f.is_file() or not f.name.isdigit():
                continue
            run = int(f.name)
            key = (case, run)
            if key in records:
                raise ValueError(f"duplicate case/run: {key}")
            records[key] = parse_helpers(f.read_text(encoding="utf-8"), str(f))
    return records


def load_from_zip(path: Path) -> Dict[Tuple[int, int], Set[str]]:
    records: Dict[Tuple[int, int], Set[str]] = {}
    with zipfile.ZipFile(path) as z:
        for name in sorted(z.namelist()):
            if name.endswith("/") or name.startswith("__MACOSX/"):
                continue
            cm = CASE_RE.search(name)
            rm = RUN_RE.search(name)
            if not cm or not rm:
                continue
            case = int(cm.group(1))
            run = int(rm.group(1))
            key = (case, run)
            if key in records:
                raise ValueError(f"duplicate case/run: {key}")
            text = z.read(name).decode("utf-8")
            records[key] = parse_helpers(text, name)
    return records


def jaccard(a: Set[str], b: Set[str]) -> float:
    u = a | b
    return 1.0 if not u else len(a & b) / len(u)


def write_csv(path: Path, fields: List[str], rows: Iterable[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("dataset", type=Path,
                    help="Unpacked dataset directory or .zip archive")
    ap.add_argument("--label", default=None,
                    help="Model label stored in CSVs; defaults to input name")
    ap.add_argument("--out", type=Path, default=Path("helper_summary"),
                    help="Output directory")
    ap.add_argument("--expected-runs", type=int, default=5,
                    help="Expected runs per case; default: 5")
    args = ap.parse_args()

    dataset = args.dataset.expanduser().resolve()
    if dataset.is_dir():
        records = load_from_directory(dataset)
        default_label = dataset.name
    elif dataset.is_file() and dataset.suffix.lower() == ".zip":
        records = load_from_zip(dataset)
        default_label = dataset.stem
    else:
        raise SystemExit(f"Dataset not found or unsupported: {dataset}")

    if not records:
        raise SystemExit("No case_N/RUN records found")

    label = args.label or default_label
    args.out.mkdir(parents=True, exist_ok=True)

    by_case: Dict[int, List[Tuple[int, Set[str]]]] = defaultdict(list)
    for (case, run), helpers in records.items():
        by_case[case].append((run, helpers))

    summary_rows = []
    freq_rows = []
    pair_rows = []
    summary_text: List[str] = []

    for case in sorted(by_case):
        runs = sorted(by_case[case])
        if args.expected_runs and len(runs) != args.expected_runs:
            raise SystemExit(
                f"case {case}: found {len(runs)} runs, expected {args.expected_runs}"
            )

        sets = [s for _, s in runs]
        common = set.intersection(*sets)
        union = set.union(*sets)
        noncommon = union - common
        counts = Counter(h for s in sets for h in s)
        sizes = [len(s) for s in sets]

        pair_values = []
        for (ra, a), (rb, b) in itertools.combinations(runs, 2):
            inter = len(a & b)
            uni = len(a | b)
            j = jaccard(a, b)
            pair_values.append(j)
            pair_rows.append({
                "model": label,
                "case": case,
                "run_a": ra,
                "run_b": rb,
                "intersection": inter,
                "union": uni,
                "jaccard": f"{j:.9f}",
            })

        mean_j = statistics.mean(pair_values) if pair_values else 1.0

        summary_rows.append({
            "model": label,
            "case": case,
            "runs": len(runs),
            "common": len(common),
            "non_common": len(noncommon),
            "min_helpers": min(sizes),
            "max_helpers": max(sizes),
            "mean_helpers": f"{statistics.mean(sizes):.6f}",
            "mean_pairwise_jaccard": f"{mean_j:.9f}",
        })

        summary_text.append(f"Case {case}")
        summary_text.append(f"Found runs: {', '.join(str(r) for r, _ in runs)}")
        summary_text.append(f"Number of runs: {len(runs)}")
        summary_text.append("")
        summary_text.append("=== Helper occurrence summary ===")
        summary_text.append(f"{'helper':36s} {'count':7s} runs")
        summary_text.append("-" * 70)
        for h in sorted(union):
            present = [str(r) for r, s in runs if h in s]
            summary_text.append(
                f"{h:36s} {counts[h]}/{len(runs):<5d} {', '.join(present)}"
            )
            freq_rows.append({
                "model": label,
                "case": case,
                "helper": h,
                "count": counts[h],
                "runs_total": len(runs),
                "runs": ";".join(present),
                "common_to_all": int(counts[h] == len(runs)),
            })

        summary_text.append("")
        summary_text.append("=== Helpers common to all runs ===")
        summary_text.extend(sorted(common) or ["(none)"])
        summary_text.append("")
        summary_text.append("=== Helpers not common to all runs ===")
        if noncommon:
            for h in sorted(noncommon):
                present = [str(r) for r, s in runs if h in s]
                summary_text.append(
                    f"{h}: {counts[h]}/{len(runs)}, runs {', '.join(present)}"
                )
        else:
            summary_text.append("(none)")
        summary_text.append("")
        summary_text.append("=== Stability summary ===")
        summary_text.append(
            f"common={len(common)}, non_common={len(noncommon)}, "
            f"min={min(sizes)}, max={max(sizes)}, "
            f"mean_pairwise_Jaccard={mean_j:.6f}"
        )
        summary_text.append("")
        summary_text.append("=" * 80)
        summary_text.append("")

    write_csv(
        args.out / "helper_stability.csv",
        ["model", "case", "runs", "common", "non_common",
         "min_helpers", "max_helpers", "mean_helpers",
         "mean_pairwise_jaccard"],
        summary_rows,
    )
    write_csv(
        args.out / "helper_frequencies.csv",
        ["model", "case", "helper", "count", "runs_total", "runs",
         "common_to_all"],
        freq_rows,
    )
    write_csv(
        args.out / "pairwise_jaccard.csv",
        ["model", "case", "run_a", "run_b", "intersection", "union",
         "jaccard"],
        pair_rows,
    )
    (args.out / "summary.txt").write_text(
        "\n".join(summary_text), encoding="utf-8"
    )

    print(f"{'Case':>4} {'Runs':>4} {'Common':>6} {'Noncommon':>9} "
          f"{'Min':>4} {'Max':>4} {'Jaccard':>8}")
    for row in summary_rows:
        print(
            f"{row['case']:>4} {row['runs']:>4} {row['common']:>6} "
            f"{row['non_common']:>9} {row['min_helpers']:>4} "
            f"{row['max_helpers']:>4} "
            f"{float(row['mean_pairwise_jaccard']):>8.3f}"
        )
    print(f"\nWrote: {args.out.resolve()}")


if __name__ == "__main__":
    main()
