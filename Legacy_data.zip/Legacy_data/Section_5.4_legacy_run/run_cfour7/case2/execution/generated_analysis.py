#!/usr/bin/env python3
import math
import sys
import matplotlib.pyplot as plt
import numpy as np

def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)

def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz

def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }

def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)

def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0

def helper_delta_phi(phi1, phi2):
    """Compute Δφ normalized to [-π, π]."""
    dphi = phi1 - phi2
    while dphi > math.pi:
        dphi -= 2 * math.pi
    while dphi < -math.pi:
        dphi += 2 * math.pi
    return dphi

def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = obj1['eta'] - obj2['eta']
    dphi = helper_delta_phi(obj1['phi'], obj2['phi'])
    return math.sqrt(deta**2 + dphi**2)

def helper_transverse_mass(visible, met):
    """Compute transverse mass of visible particle + MET."""
    dphi = helper_delta_phi(visible['phi'], met['phi'])
    return math.sqrt(2 * visible['pt'] * met['pt'] * (1 - math.cos(dphi)))

def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            # New event header (index = 0)
            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}

            # Object line
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events

def get_leptons(event):
    """Return all electrons and muons."""
    return [o for o in event['objects'] if o['type'] in (1, 2)]

def get_electrons(event):
    """Return all electrons."""
    return [o for o in event['objects'] if o['type'] == 1]

def get_muons(event):
    """Return all muons."""
    return [o for o in event['objects'] if o['type'] == 2]

def get_taus(event):
    """Return all taus."""
    return [o for o in event['objects'] if o['type'] == 3]

def get_jets(event):
    """Return all jets."""
    return [o for o in event['objects'] if o['type'] == 4]

def get_bjets(event):
    """Return all b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 1]

def get_light_jets(event):
    """Return all non-b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 0]

def helper_get_met(event):
    """Return MET object or None."""
    for o in event['objects']:
        if o['type'] == 6:
            return o
    return None

def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])

def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]

def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)

def compute_ht(event):
    """Compute HT = scalar sum of all jet pT."""
    jets = get_jets(event)
    return sum(j['pt'] for j in jets)

def n_jets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count jets passing pT and |η| cuts."""
    jets = get_jets(event)
    return sum(1 for j in jets if j['pt'] > pt_cut and abs(j['eta']) < eta_cut)

def n_bjets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count b-jets passing pT and |η| cuts."""
    bjets = get_bjets(event)
    return sum(1 for b in bjets if b['pt'] > pt_cut and abs(b['eta']) < eta_cut)

def n_leptons(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count leptons passing pT and |η| cuts."""
    leptons = get_leptons(event)
    return sum(1 for l in leptons if l['pt'] > pt_cut and abs(l['eta']) < eta_cut)

def mt_lepton_met(event):
    """Compute transverse mass of leading lepton and MET."""
    leptons = get_leptons(event)
    met = helper_get_met(event)
    if not leptons or not met:
        return 0.0
    return helper_transverse_mass(helper_get_leading(leptons), met)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <lhco_file>")
        sys.exit(1)

    filename = sys.argv[1]
    events = read_lhco(filename)

    # Histograms
    mt_lepton_met_list = []
    met_list = []
    leading_bjet_pt_list = []
    subleading_bjet_pt_list = []
    w_hadronic_mass_list = []
    top_hadronic_mass_list = []
    dr_lepton_bjet_list = []
    ht_list = []
    n_jets_list = []
    leading_bjet_eta_list = []

    cutflow = {
        "Initial": len(events),
        "Lepton Selection": 0,
        "Jet Selection": 0,
        "B-jet Selection": 0,
        "MET Selection": 0,
        "Transverse Mass Selection": 0,
        "W Hadronic Selection": 0,
        "Top Hadronic Selection": 0
    }

    for event in events:
        # Step 1: Select electrons and muons with pT > 25 GeV and |eta| < 2.5
        leptons = [l for l in get_leptons(event) if l['pt'] > 25 and abs(l['eta']) < 2.5]
        if len(leptons) != 1:
            continue
        cutflow["Lepton Selection"] += 1

        # Step 2: Select at least 4 jets with pT > 30 GeV and |eta| < 2.5
        jets = [j for j in get_jets(event) if j['pt'] > 30 and abs(j['eta']) < 2.5]
        if len(jets) < 4:
            continue
        cutflow["Jet Selection"] += 1

        # Step 3: Select at least 2 b-tagged jets
        bjets = [b for b in get_bjets(event) if b['pt'] > 30 and abs(b['eta']) < 2.5]
        if len(bjets) < 2:
            continue
        cutflow["B-jet Selection"] += 1

        # Step 4: Select MET > 20 GeV
        met = helper_get_met(event)
        if not met or met['pt'] < 20:
            continue
        cutflow["MET Selection"] += 1

        # Step 5: Select transverse mass of lepton and MET between 30 and 150 GeV
        mt = mt_lepton_met(event)
        if not (30 < mt < 150):
            continue
        cutflow["Transverse Mass Selection"] += 1
        mt_lepton_met_list.append(mt)

        # Step 6: Build hadronic W candidate from two leading non-b-tagged jets
        light_jets = [j for j in get_light_jets(event) if j['pt'] > 30 and abs(j['eta']) < 2.5]
        if len(light_jets) < 2:
            continue
        cutflow["W Hadronic Selection"] += 1

        w_hadronic = sum_objects(helper_get_leading(light_jets), helper_get_subleading(light_jets))
        w_mass = w_hadronic['mass'] if w_hadronic else 0.0
        if not (40 < w_mass < 120):
            continue
        w_hadronic_mass_list.append(w_mass)

        # Step 7: Build hadronic top candidate from leading b-jet and hadronic W
        leading_bjet = helper_get_leading(bjets)
        top_hadronic = sum_objects(leading_bjet, w_hadronic)
        top_mass = top_hadronic['mass'] if top_hadronic else 0.0
        if not (100 < top_mass < 250):
            continue
        cutflow["Top Hadronic Selection"] += 1
        top_hadronic_mass_list.append(top_mass)

        # Fill other histograms
        met_list.append(met['pt'])
        leading_bjet_pt_list.append(leading_bjet['pt'])
        subleading_bjet_pt_list.append(helper_get_subleading(bjets)['pt'])
        dr_lepton_bjet_list.append(helper_delta_r(helper_get_leading(leptons), helper_get_leading(bjets)))
        ht_list.append(compute_ht(event))
        n_jets_list.append(len(jets))
        leading_bjet_eta_list.append(leading_bjet['eta'])

    # Plotting
    plt.figure()
    plt.hist(mt_lepton_met_list, bins=40, density=True)
    plt.xlabel("MT (lepton + MET) [GeV]")
    plt.ylabel("density")
    plt.savefig("mt_lepton_met.png")
    plt.close()

    plt.figure()
    plt.hist(met_list, bins=40, density=True)
    plt.xlabel("MET [GeV]")
    plt.ylabel("density")
    plt.savefig("met.png")
    plt.close()

    plt.figure()
    plt.hist(leading_bjet_pt_list, bins=40, density=True)
    plt.xlabel("Leading b-jet pT [GeV]")
    plt.ylabel("density")
    plt.savefig("leading_bjet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_bjet_pt_list, bins=40, density=True)
    plt.xlabel("Subleading b-jet pT [GeV]")
    plt.ylabel("density")
    plt.savefig("subleading_bjet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(w_hadronic_mass_list, bins=40, density=True)
    plt.xlabel("W hadronic mass [GeV]")
    plt.ylabel("density")
    plt.savefig("w_hadronic_mass.png")
    plt.close()

    plt.figure()
    plt.hist(top_hadronic_mass_list, bins=40, density=True)
    plt.xlabel("Top hadronic mass [GeV]")
    plt.ylabel("density")
    plt.savefig("top_hadronic_mass.png")
    plt.close()

    plt.figure()
    plt.hist(dr_lepton_bjet_list, bins=40, density=True)
    plt.xlabel("ΔR (lepton, b-jet)")
    plt.ylabel("density")
    plt.savefig("dr_lepton_bjet.png")
    plt.close()

    plt.figure()
    plt.hist(ht_list, bins=40, density=True)
    plt.xlabel("HT [GeV]")
    plt.ylabel("density")
    plt.savefig("ht.png")
    plt.close()

    plt.figure()
    plt.hist(n_jets_list, bins=40, density=True)
    plt.xlabel("Number of jets")
    plt.ylabel("density")
    plt.savefig("n_jets.png")
    plt.close()

    plt.figure()
    plt.hist(leading_bjet_eta_list, bins=40, density=True)
    plt.xlabel("Leading b-jet η")
    plt.ylabel("density")
    plt.savefig("leading_bjet_eta.png")
    plt.close()

    # Print cutflow
    for key, value in cutflow.items():
        print(f"{key}: {value} events")

if __name__ == "__main__":
    main()
