#!/usr/bin/env python3
import math
import sys
import numpy as np
import matplotlib.pyplot as plt

def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)

def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz

def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }

def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)

def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0

def helper_delta_phi(phi1, phi2):
    """Compute Δφ normalized to [-π, π]."""
    dphi = phi1 - phi2
    while dphi > math.pi:
        dphi -= 2 * math.pi
    while dphi < -math.pi:
        dphi += 2 * math.pi
    return dphi

def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = obj1['eta'] - obj2['eta']
    dphi = helper_delta_phi(obj1['phi'], obj2['phi'])
    return math.sqrt(deta**2 + dphi**2)

def cos_theta_star_collins_soper(obj1, obj2):
    """
    Compute signed cos(theta*) in the Collins-Soper frame for a two-object system.

    Intended for diphoton systems such as H -> gamma gamma.
    Return value is signed; use abs(...) for |cos(theta*)|.
    """
    E1, px1, py1, pz1 = four_momentum(obj1)
    E2, px2, py2, pz2 = four_momentum(obj2)

    system = sum_objects(obj1, obj2)
    if system is None:
        return 0.0

    mass = system["mass"]
    pt = system["pt"]

    if mass <= 0.0:
        return 0.0

    p1_plus = E1 + pz1
    p1_minus = E1 - pz1
    p2_plus = E2 + pz2
    p2_minus = E2 - pz2

    denom = mass * math.sqrt(mass * mass + pt * pt)
    if denom <= 0.0:
        return 0.0

    cos_theta = (p1_plus * p2_minus - p1_minus * p2_plus) / denom

    if cos_theta > 1.0:
        return 1.0
    if cos_theta < -1.0:
        return -1.0
    return cos_theta

def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            # New event header (index = 0)
            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}

            # Object line
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events

def get_photons(event):
    """Return all photons."""
    return [o for o in event['objects'] if o['type'] == 0]

def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])

def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]

def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <lhco_file>")
        sys.exit(1)

    filename = sys.argv[1]
    events = read_lhco(filename)

    cutflow = {
        "Initial": len(events),
        "Photon selection": 0,
        "At least 2 photons": 0,
        "Leading photon pT > 35 GeV": 0,
        "Subleading photon pT > 25 GeV": 0,
        "Diphoton mass 105-160 GeV": 0,
        "Leading photon pT / m_gammagamma > 0.35": 0,
        "Subleading photon pT / m_gammagamma > 0.25": 0,
        "Final": 0
    }

    diphoton_mass_list = []
    leading_photon_pt_list = []
    subleading_photon_pt_list = []
    diphoton_pt_list = []
    leading_photon_eta_list = []
    subleading_photon_eta_list = []
    delta_r_list = []
    delta_phi_list = []
    cos_theta_list = []

    for event in events:
        # Step 1: Select photons with pT > 25 GeV and |eta| < 2.37
        photons = get_photons(event)
        photons = [p for p in photons if p['pt'] > 25 and abs(p['eta']) < 2.37]
        photons = [p for p in photons if not (1.37 < abs(p['eta']) < 1.52)]

        cutflow["Photon selection"] += 1

        if len(photons) < 2:
            continue

        cutflow["At least 2 photons"] += 1

        # Step 2: Define leading and subleading photons
        photons_sorted = sort_by_pt(photons)
        leading_photon = helper_get_leading(photons_sorted)
        subleading_photon = helper_get_subleading(photons_sorted)

        if leading_photon is None or subleading_photon is None:
            continue

        if leading_photon['pt'] < 35:
            continue

        cutflow["Leading photon pT > 35 GeV"] += 1

        if subleading_photon['pt'] < 25:
            continue

        cutflow["Subleading photon pT > 25 GeV"] += 1

        # Step 3: Build diphoton system
        diphoton = sum_objects(leading_photon, subleading_photon)
        m_gammagamma = diphoton['mass'] if diphoton else 0.0

        if m_gammagamma < 105 or m_gammagamma > 160:
            continue

        cutflow["Diphoton mass 105-160 GeV"] += 1

        # Step 4: Check pT ratios
        if leading_photon['pt'] / m_gammagamma < 0.35:
            continue

        cutflow["Leading photon pT / m_gammagamma > 0.35"] += 1

        if subleading_photon['pt'] / m_gammagamma < 0.25:
            continue

        cutflow["Subleading photon pT / m_gammagamma > 0.25"] += 1

        cutflow["Final"] += 1

        # Collect data for plots
        diphoton_mass_list.append(m_gammagamma)
        leading_photon_pt_list.append(leading_photon['pt'])
        subleading_photon_pt_list.append(subleading_photon['pt'])

        # Compute diphoton pT
        px = leading_photon['pt'] * math.cos(leading_photon['phi']) + subleading_photon['pt'] * math.cos(subleading_photon['phi'])
        py = leading_photon['pt'] * math.sin(leading_photon['phi']) + subleading_photon['pt'] * math.sin(subleading_photon['phi'])
        diphoton_pt = math.sqrt(px**2 + py**2)
        diphoton_pt_list.append(diphoton_pt)

        leading_photon_eta_list.append(leading_photon['eta'])
        subleading_photon_eta_list.append(subleading_photon['eta'])

        delta_r = helper_delta_r(leading_photon, subleading_photon)
        delta_r_list.append(delta_r)

        delta_phi = helper_delta_phi(leading_photon['phi'], subleading_photon['phi'])
        delta_phi_list.append(delta_phi)

        cos_theta = abs(cos_theta_star_collins_soper(leading_photon, subleading_photon))
        cos_theta_list.append(cos_theta)

    # Plotting
    plt.figure()
    plt.hist(diphoton_mass_list, bins=40, range=(100, 160), density=True)
    plt.xlabel("m(gammagamma) [GeV]")
    plt.ylabel("density")
    plt.savefig("diphoton_mass.png")
    plt.close()

    plt.figure()
    plt.hist(leading_photon_pt_list, bins=40, density=True)
    plt.xlabel("leading photon pT [GeV]")
    plt.ylabel("density")
    plt.savefig("leading_photon_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_photon_pt_list, bins=40, density=True)
    plt.xlabel("subleading photon pT [GeV]")
    plt.ylabel("density")
    plt.savefig("subleading_photon_pt.png")
    plt.close()

    plt.figure()
    plt.hist(diphoton_pt_list, bins=40, density=True)
    plt.xlabel("diphoton pT [GeV]")
    plt.ylabel("density")
    plt.savefig("diphoton_pt.png")
    plt.close()

    plt.figure()
    plt.hist(leading_photon_eta_list, bins=40, density=True)
    plt.xlabel("leading photon eta")
    plt.ylabel("density")
    plt.savefig("leading_photon_eta.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_photon_eta_list, bins=40, density=True)
    plt.xlabel("subleading photon eta")
    plt.ylabel("density")
    plt.savefig("subleading_photon_eta.png")
    plt.close()

    plt.figure()
    plt.hist(delta_r_list, bins=40, density=True)
    plt.xlabel("delta R between photons")
    plt.ylabel("density")
    plt.savefig("delta_r_photons.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_list, bins=40, density=True)
    plt.xlabel("delta phi between photons")
    plt.ylabel("density")
    plt.savefig("delta_phi_photons.png")
    plt.close()

    plt.figure()
    plt.hist(cos_theta_list, bins=40, density=True)
    plt.xlabel("|cos(theta*)|")
    plt.ylabel("density")
    plt.savefig("cos_theta_star.png")
    plt.close()

    # Save to CSV
    import csv
    with open("diphoton_data.csv", "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["m_gammagamma", "leading_photon_pt", "subleading_photon_pt", "delta_r", "diphoton_pt", "cos_theta_star"])
        for i in range(len(diphoton_mass_list)):
            writer.writerow([
                diphoton_mass_list[i],
                leading_photon_pt_list[i],
                subleading_photon_pt_list[i],
                delta_r_list[i],
                diphoton_pt_list[i],
                cos_theta_list[i]
            ])

    # Print cutflow
    for key, value in cutflow.items():
        print(f"{key}: {value}")

if __name__ == "__main__":
    main()
