import sys
import numpy as np
import matplotlib.pyplot as plt

def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)

def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz

def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }

def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)

def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0

def helper_delta_phi(phi1, phi2):
    """Compute Δφ normalized to [-π, π]."""
    dphi = phi1 - phi2
    while dphi > math.pi:
        dphi -= 2 * math.pi
    while dphi < -math.pi:
        dphi += 2 * math.pi
    return dphi

def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = obj1['eta'] - obj2['eta']
    dphi = helper_delta_phi(obj1['phi'], obj2['phi'])
    return math.sqrt(deta**2 + dphi**2)

def centrality_between_jets(obj, jet1, jet2):
    """
    Compute eta centrality of obj relative to two jets.

    centrality = |eta_obj - eta_center_jj| / |delta_eta_jj|
    Smaller values mean obj is closer to the midpoint between the two jets.
    """
    eta_gap = abs(jet1["eta"] - jet2["eta"])
    if eta_gap <= 0.0:
        return 0.0

    eta_center = 0.5 * (jet1["eta"] + jet2["eta"])
    return abs(obj["eta"] - eta_center) / eta_gap

def opposite_sign(obj1, obj2):
    """Check if two objects have opposite charge."""
    return obj1['charge'] * obj2['charge'] < 0

def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            # New event header (index = 0)
            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}

            # Object line
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events

def get_taus(event):
    """Return all taus."""
    return [o for o in event['objects'] if o['type'] == 3]

def get_jets(event):
    """Return all jets."""
    return [o for o in event['objects'] if o['type'] == 4]

def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])

def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]

def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)

def dijet_mass(event):
    """Compute invariant mass of two leading jets."""
    jets = sort_by_pt(get_jets(event))
    if len(jets) < 2:
        return 0.0
    return helper_invariant_mass(jets[:2])

def n_jets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count jets passing pT and |η| cuts."""
    jets = get_jets(event)
    return sum(1 for j in jets if j['pt'] > pt_cut and abs(j['eta']) < eta_cut)

def get_bjets(event):
    """Return all b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 1]

def n_bjets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count b-jets passing pT and |η| cuts."""
    bjets = get_bjets(event)
    return sum(1 for b in bjets if b['pt'] > pt_cut and abs(b['eta']) < eta_cut)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <lhco_file>")
        sys.exit(1)

    filename = sys.argv[1]
    events = read_lhco(filename)

    # Histograms
    ditau_masses = []
    dijet_masses = []
    delta_eta_jj = []
    leading_tau_pt = []
    subleading_tau_pt = []
    leading_jet_pt = []
    subleading_jet_pt = []
    delta_r_tt = []
    delta_phi_ditau_dijet = []
    centrality_tt = []

    cutflow = {
        "Initial": len(events),
        "Tau pT > 20 GeV and |eta| < 2.3": 0,
        "At least 2 taus": 0,
        "Opposite-sign tau pair": 0,
        "Jet pT > 30 GeV and |eta| < 4.7": 0,
        "At least 2 jets": 0,
        "m_jj > 400 GeV": 0,
        "|delta eta| between jets > 2.5": 0,
        "Ditau mass between 60 and 150 GeV": 0,
        "No b-jets": 0,
        "Final": 0
    }

    for event in events:
        # Step 1: Select taus with pT > 20 GeV and |eta| < 2.3
        taus = [t for t in get_taus(event) if t['pt'] > 20 and abs(t['eta']) < 2.3]
        if len(taus) < 2:
            continue
        cutflow["Tau pT > 20 GeV and |eta| < 2.3"] += 1

        # Step 2: Require at least 2 taus
        if len(taus) < 2:
            continue
        cutflow["At least 2 taus"] += 1

        # Step 3: Opposite-sign tau pair
        tau1 = helper_get_leading(taus)
        tau2 = helper_get_subleading(taus)
        if not opposite_sign(tau1, tau2):
            continue
        cutflow["Opposite-sign tau pair"] += 1

        # Step 4: Select jets with pT > 30 GeV and |eta| < 4.7
        jets = [j for j in get_jets(event) if j['pt'] > 30 and abs(j['eta']) < 4.7]
        if len(jets) < 2:
            continue
        cutflow["Jet pT > 30 GeV and |eta| < 4.7"] += 1

        # Step 5: Require at least 2 jets
        if len(jets) < 2:
            continue
        cutflow["At least 2 jets"] += 1

        # Step 6: m_jj > 400 GeV
        dijet_mass_val = dijet_mass(event)
        if dijet_mass_val < 400:
            continue
        cutflow["m_jj > 400 GeV"] += 1

        # Step 7: |delta eta| between jets > 2.5
        jet1 = helper_get_leading(jets)
        jet2 = helper_get_subleading(jets)
        delta_eta = abs(jet1['eta'] - jet2['eta'])
        if delta_eta < 2.5:
            continue
        cutflow["|delta eta| between jets > 2.5"] += 1

        # Step 8: Ditau mass between 60 and 150 GeV
        ditau_mass = helper_invariant_mass(tau1, tau2)
        if not (60 < ditau_mass < 150):
            continue
        cutflow["Ditau mass between 60 and 150 GeV"] += 1

        # Step 9: Veto events with b-tagged jets
        if n_bjets(event, pt_cut=30, eta_cut=4.7) > 0:
            continue
        cutflow["No b-jets"] += 1

        # Step 10: Final selection
        cutflow["Final"] += 1

        # Fill histograms
        ditau_masses.append(ditau_mass)
        dijet_masses.append(dijet_mass_val)
        delta_eta_jj.append(delta_eta)
        leading_tau_pt.append(tau1['pt'])
        subleading_tau_pt.append(tau2['pt'])
        leading_jet_pt.append(jet1['pt'])
        subleading_jet_pt.append(jet2['pt'])
        delta_r_tt.append(helper_delta_r(tau1, tau2))
        delta_phi_ditau_dijet.append(helper_delta_phi(
            tau1['phi'],
            jet1['phi']
        ))
        centrality_tt.append(centrality_between_jets(tau1, jet1, jet2))

    # Print cutflow
    for key, value in cutflow.items():
        print(f"{key}: {value}")

    # Plot histograms
    plt.figure()
    plt.hist(ditau_masses, bins=40, range=(50, 160), density=True)
    plt.xlabel("Ditau Mass (GeV)")
    plt.ylabel("Density")
    plt.savefig("ditau_mass.png")
    plt.close()

    plt.figure()
    plt.hist(dijet_masses, bins=40, range=(200, 2000), density=True)
    plt.xlabel("Dijet Mass (GeV)")
    plt.ylabel("Density")
    plt.savefig("dijet_mass.png")
    plt.close()

    plt.figure()
    plt.hist(delta_eta_jj, bins=40, density=True)
    plt.xlabel("Delta Eta (Jets)")
    plt.ylabel("Density")
    plt.savefig("delta_eta_jj.png")
    plt.close()

    plt.figure()
    plt.hist(leading_tau_pt, bins=40, density=True)
    plt.xlabel("Leading Tau pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("leading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_tau_pt, bins=40, density=True)
    plt.xlabel("Subleading Tau pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("subleading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(leading_jet_pt, bins=40, density=True)
    plt.xlabel("Leading Jet pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("leading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_jet_pt, bins=40, density=True)
    plt.xlabel("Subleading Jet pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("subleading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(delta_r_tt, bins=40, density=True)
    plt.xlabel("Delta R (Taus)")
    plt.ylabel("Density")
    plt.savefig("delta_r_tt.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_ditau_dijet, bins=40, density=True)
    plt.xlabel("Delta Phi (Ditau, Dijet)")
    plt.ylabel("Density")
    plt.savefig("delta_phi_ditau_dijet.png")
    plt.close()

    plt.figure()
    plt.hist(centrality_tt, bins=40, density=True)
    plt.xlabel("Centrality (Ditau w.r.t. Jets)")
    plt.ylabel("Density")
    plt.savefig("centrality_tt.png")
    plt.close()

if __name__ == "__main__":
    main()
