import math
import sys
import numpy as np
import matplotlib.pyplot as plt


def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)


def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz


def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }


def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)


def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0


def helper_delta_phi(phi1, phi2):
    """Compute Δφ normalized to [-π, π]."""
    dphi = phi1 - phi2
    while dphi > math.pi:
        dphi -= 2 * math.pi
    while dphi < -math.pi:
        dphi += 2 * math.pi
    return dphi


def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = obj1['eta'] - obj2['eta']
    dphi = helper_delta_phi(obj1['phi'], obj2['phi'])
    return math.sqrt(deta**2 + dphi**2)


def centrality_between_jets(obj, jet1, jet2):
    """
    Compute eta centrality of obj relative to two jets.

    centrality = |eta_obj - eta_center_jj| / |delta_eta_jj|
    Smaller values mean obj is closer to the midpoint between the two jets.
    """
    eta_gap = abs(jet1["eta"] - jet2["eta"])
    if eta_gap <= 0.0:
        return 0.0

    eta_center = 0.5 * (jet1["eta"] + jet2["eta"])
    return abs(obj["eta"] - eta_center) / eta_gap


def opposite_sign(obj1, obj2):
    """Check if two objects have opposite charge."""
    return obj1['charge'] * obj2['charge'] < 0


def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            # New event header (index = 0)
            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}

            # Object line
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events


def get_taus(event):
    """Return all taus."""
    return [o for o in event['objects'] if o['type'] == 3]


def get_jets(event):
    """Return all jets."""
    return [o for o in event['objects'] if o['type'] == 4]


def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])


def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]


def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)


def dijet_mass(event):
    """Compute invariant mass of two leading jets."""
    jets = sort_by_pt(get_jets(event))
    if len(jets) < 2:
        return 0.0
    return helper_invariant_mass(jets[:2])


def n_jets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count jets passing pT and |η| cuts."""
    jets = get_jets(event)
    return sum(1 for j in jets if j['pt'] > pt_cut and abs(j['eta']) < eta_cut)


def get_bjets(event):
    """Return all b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 1]


def n_bjets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count b-jets passing pT and |η| cuts."""
    bjets = get_bjets(event)
    return sum(1 for b in bjets if b['pt'] > pt_cut and abs(b['eta']) < eta_cut)


def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <lhco_file>")
        sys.exit(1)

    filename = sys.argv[1]
    events = read_lhco(filename)

    # Histograms
    ditau_masses = []
    dijet_masses = []
    delta_eta_jj = []
    leading_tau_pt = []
    subleading_tau_pt = []
    leading_jet_pt = []
    subleading_jet_pt = []
    delta_r_tt = []
    delta_phi_ditau_dijet = []
    centrality_tt = []

    cutflow = {
        "Initial": len(events),
        "Tau selection": 0,
        "At least 2 taus": 0,
        "Jet selection": 0,
        "At least 2 jets": 0,
        "Opposite sign taus": 0,
        "m_jj > 400 GeV": 0,
        "delta eta jj > 2.5": 0,
        "ditau mass 60-150 GeV": 0,
        "No b-jets": 0,
        "Final": 0
    }

    for event in events:
        # Cutflow: Initial
        cutflow["Initial"] += 1

        # Tau selection: pT > 20 GeV, |eta| < 2.3
        taus = [t for t in get_taus(event) if t['pt'] > 20 and abs(t['eta']) < 2.3]
        if len(taus) < 2:
            continue
        cutflow["Tau selection"] += 1

        # At least 2 taus
        cutflow["At least 2 taus"] += 1

        # Jet selection: pT > 30 GeV, |eta| < 4.7
        jets = [j for j in get_jets(event) if j['pt'] > 30 and abs(j['eta']) < 4.7]
        if len(jets) < 2:
            continue
        cutflow["Jet selection"] += 1

        # At least 2 jets
        cutflow["At least 2 jets"] += 1

        # Opposite sign taus
        leading_tau = helper_get_leading(taus)
        subleading_tau = helper_get_subleading(taus)
        if not opposite_sign(leading_tau, subleading_tau):
            continue
        cutflow["Opposite sign taus"] += 1

        # Build ditau system
        ditau_mass = helper_invariant_mass(leading_tau, subleading_tau)
        if not (60 < ditau_mass < 150):
            continue
        cutflow["ditau mass 60-150 GeV"] += 1

        # Build dijet system
        leading_jet = helper_get_leading(jets)
        subleading_jet = helper_get_subleading(jets)
        dijet_mass_val = dijet_mass(event)
        if dijet_mass_val < 400:
            continue
        cutflow["m_jj > 400 GeV"] += 1

        # Delta eta between jets
        delta_eta = abs(leading_jet['eta'] - subleading_jet['eta'])
        if delta_eta < 2.5:
            continue
        cutflow["delta eta jj > 2.5"] += 1

        # Veto b-jets
        if n_bjets(event, pt_cut=30, eta_cut=4.7) > 0:
            continue
        cutflow["No b-jets"] += 1

        # Final selection
        cutflow["Final"] += 1

        # Fill histograms
        ditau_masses.append(ditau_mass)
        dijet_masses.append(dijet_mass_val)
        delta_eta_jj.append(delta_eta)
        leading_tau_pt.append(leading_tau['pt'])
        subleading_tau_pt.append(subleading_tau['pt'])
        leading_jet_pt.append(leading_jet['pt'])
        subleading_jet_pt.append(subleading_jet['pt'])
        delta_r_tt.append(helper_delta_r(leading_tau, subleading_tau))
        delta_phi_ditau_dijet.append(helper_delta_phi(
            helper_invariant_mass(leading_tau, subleading_tau)['phi'],
            helper_invariant_mass(leading_jet, subleading_jet)['phi']
        ))
        centrality_tt.append(centrality_between_jets(
            helper_invariant_mass(leading_tau, subleading_tau),
            leading_jet, subleading_jet
        ))

    # Print cutflow
    for key, value in cutflow.items():
        print(f"{key}: {value}")

    # Plot histograms
    plt.figure()
    plt.hist(ditau_masses, bins=40, range=(50, 160), density=True)
    plt.xlabel("ditau mass (GeV)")
    plt.ylabel("density")
    plt.savefig("ditau_mass.png")
    plt.close()

    plt.figure()
    plt.hist(dijet_masses, bins=40, range=(200, 2000), density=True)
    plt.xlabel("dijet mass (GeV)")
    plt.ylabel("density")
    plt.savefig("dijet_mass.png")
    plt.close()

    plt.figure()
    plt.hist(delta_eta_jj, bins=40, density=True)
    plt.xlabel("delta eta (jj)")
    plt.ylabel("density")
    plt.savefig("delta_eta_jj.png")
    plt.close()

    plt.figure()
    plt.hist(leading_tau_pt, bins=40, density=True)
    plt.xlabel("leading tau pT (GeV)")
    plt.ylabel("density")
    plt.savefig("leading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_tau_pt, bins=40, density=True)
    plt.xlabel("subleading tau pT (GeV)")
    plt.ylabel("density")
    plt.savefig("subleading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(leading_jet_pt, bins=40, density=True)
    plt.xlabel("leading jet pT (GeV)")
    plt.ylabel("density")
    plt.savefig("leading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_jet_pt, bins=40, density=True)
    plt.xlabel("subleading jet pT (GeV)")
    plt.ylabel("density")
    plt.savefig("subleading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(delta_r_tt, bins=40, density=True)
    plt.xlabel("delta R (tt)")
    plt.ylabel("density")
    plt.savefig("delta_r_tt.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_ditau_dijet, bins=40, density=True)
    plt.xlabel("delta phi (ditau, dijet)")
    plt.ylabel("density")
    plt.savefig("delta_phi_ditau_dijet.png")
    plt.close()

    plt.figure()
    plt.hist(centrality_tt, bins=40, density=True)
    plt.xlabel("centrality (tt)")
    plt.ylabel("density")
    plt.savefig("centrality_tt.png")
    plt.close()


if __name__ == "__main__":
    main()
