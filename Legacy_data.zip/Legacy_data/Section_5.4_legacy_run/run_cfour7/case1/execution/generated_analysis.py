import math
import sys
import numpy as np
import matplotlib.pyplot as plt

def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)

def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz

def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }

def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)

def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0

def helper_delta_phi(phi1, phi2):
    """Compute Δφ normalized to [-π, π]."""
    dphi = phi1 - phi2
    while dphi > math.pi:
        dphi -= 2 * math.pi
    while dphi < -math.pi:
        dphi += 2 * math.pi
    return dphi

def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = obj1['eta'] - obj2['eta']
    dphi = helper_delta_phi(obj1['phi'], obj2['phi'])
    return math.sqrt(deta**2 + dphi**2)

def helper_transverse_mass(visible, met):
    """Compute transverse mass of visible particle + MET."""
    dphi = helper_delta_phi(visible['phi'], met['phi'])
    return math.sqrt(2 * visible['pt'] * met['pt'] * (1 - math.cos(dphi)))

def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            # New event header (index = 0)
            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}

            # Object line
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events

def get_leptons(event):
    """Return all electrons and muons."""
    return [o for o in event['objects'] if o['type'] in (1, 2)]

def get_electrons(event):
    """Return all electrons."""
    return [o for o in event['objects'] if o['type'] == 1]

def get_muons(event):
    """Return all muons."""
    return [o for o in event['objects'] if o['type'] == 2]

def get_jets(event):
    """Return all jets."""
    return [o for o in event['objects'] if o['type'] == 4]

def get_bjets(event):
    """Return all b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 1]

def get_light_jets(event):
    """Return all non-b-tagged jets."""
    return [o for o in event['objects'] if o['type'] == 4 and int(o['btag']) == 0]

def helper_get_met(event):
    """Return MET object or None."""
    for o in event['objects']:
        if o['type'] == 6:
            return o
    return None

def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])

def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]

def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)

def helper_delta_phi_l_twojet(event):
    """Compute Delta phi between leading lepton and the two-jet system."""
    leptons = get_leptons(event)
    if len(leptons) < 1:
        return 0.0

    jets = sort_by_pt(get_jets(event))
    if len(jets) < 2:
        return 0.0

    lepton = helper_get_leading(leptons)
    dijet_obj = sum_objects(jets[:2])

    return helper_delta_phi(lepton['phi'], dijet_obj['phi'])

def n_jets(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count jets passing pT and |η| cuts."""
    jets = get_jets(event)
    return sum(1 for j in jets if j['pt'] > pt_cut and abs(j['eta']) < eta_cut)

def n_leptons(event, pt_cut=0.0, eta_cut=float('inf')):
    """Count leptons passing pT and |η| cuts."""
    leptons = get_leptons(event)
    return sum(1 for l in leptons if l['pt'] > pt_cut and abs(l['eta']) < eta_cut)

def dijet_mass(event):
    """Compute invariant mass of two leading jets."""
    jets = sort_by_pt(get_jets(event))
    if len(jets) < 2:
        return 0.0
    return helper_invariant_mass(jets[:2])

def mt_lepton_met(event):
    """Compute transverse mass of leading lepton and MET."""
    leptons = get_leptons(event)
    met = helper_get_met(event)
    if not leptons or not met:
        return 0.0
    return helper_transverse_mass(helper_get_leading(leptons), met)

def main():
    if len(sys.argv) < 2:
        print("Usage: python script.py <lhco_file>")
        sys.exit(1)

    filename = sys.argv[1]
    events = read_lhco(filename)

    cutflow = {
        "Initial": len(events),
        "Lepton Selection": 0,
        "Jet Selection": 0,
        "MET Selection": 0,
        "B-jet Veto": 0,
        "Transverse Mass Cut": 0,
        "Dijet Mass Cut": 0,
        "Delta R Cut": 0,
        "Final": 0
    }

    mt_list = []
    dijet_mass_list = []
    met_list = []
    lepton_pt_list = []
    jet1_pt_list = []
    jet2_pt_list = []
    delta_r_list = []
    delta_phi_lep_met_list = []
    delta_phi_lep_twojet_list = []
    lepton_eta_list = []

    for event in events:
        # Step 1: Lepton Selection
        leptons = get_leptons(event)
        electrons = get_electrons(event)
        muons = get_muons(event)
        selected_leptons = []
        for l in leptons:
            if l['type'] == 1 and l['pt'] > 25 and abs(l['eta']) < 2.5:
                selected_leptons.append(l)
            elif l['type'] == 2 and l['pt'] > 20 and abs(l['eta']) < 2.4:
                selected_leptons.append(l)
        if len(selected_leptons) != 1:
            continue
        cutflow["Lepton Selection"] += 1

        # Step 2: Jet Selection
        jets = get_jets(event)
        selected_jets = [j for j in jets if j['pt'] > 30 and abs(j['eta']) < 2.5]
        if len(selected_jets) < 2:
            continue
        cutflow["Jet Selection"] += 1

        # Step 3: MET Selection
        met = helper_get_met(event)
        if not met or met['pt'] < 30:
            continue
        cutflow["MET Selection"] += 1

        # Step 4: B-jet Veto
        bjets = get_bjets(event)
        if bjets:
            continue
        cutflow["B-jet Veto"] += 1

        # Step 5: Transverse Mass Cut
        lepton = helper_get_leading(selected_leptons)
        mt = helper_transverse_mass(lepton, met)
        if mt < 40 or mt > 120:
            continue
        cutflow["Transverse Mass Cut"] += 1

        # Step 6: Dijet Mass Cut
        jet1 = helper_get_leading(selected_jets)
        jet2 = helper_get_subleading(selected_jets)
        dijet_mass_val = helper_invariant_mass([jet1, jet2])
        if dijet_mass_val < 60 or dijet_mass_val > 100:
            continue
        cutflow["Dijet Mass Cut"] += 1

        # Step 7: Delta R Cut
        delta_r = helper_delta_r(jet1, jet2)
        if delta_r >= 3.0:
            continue
        cutflow["Delta R Cut"] += 1

        # Save to lists for plotting
        mt_list.append(mt)
        dijet_mass_list.append(dijet_mass_val)
        met_list.append(met['pt'])
        lepton_pt_list.append(lepton['pt'])
        jet1_pt_list.append(jet1['pt'])
        jet2_pt_list.append(jet2['pt'])
        delta_r_list.append(delta_r)
        delta_phi_lep_met = helper_delta_phi(lepton['phi'], met['phi'])
        delta_phi_lep_met_list.append(delta_phi_lep_met)
        delta_phi_lep_twojet = helper_delta_phi_l_twojet(event)
        delta_phi_lep_twojet_list.append(delta_phi_lep_twojet)
        lepton_eta_list.append(lepton['eta'])

        cutflow["Final"] += 1

    # Print cutflow
    for key, value in cutflow.items():
        print(f"{key}: {value} events")

    # Plotting
    plt.figure()
    plt.hist(mt_list, bins=40, range=(30, 150), density=True)
    plt.xlabel("Transverse Mass (GeV)")
    plt.ylabel("Density")
    plt.savefig("mt_hist.png")
    plt.close()

    plt.figure()
    plt.hist(dijet_mass_list, bins=40, range=(40, 120), density=True)
    plt.xlabel("Dijet Mass (GeV)")
    plt.ylabel("Density")
    plt.savefig("dijet_mass_hist.png")
    plt.close()

    plt.figure()
    plt.hist(met_list, bins=40, range=(0, 200), density=True)
    plt.xlabel("MET (GeV)")
    plt.ylabel("Density")
    plt.savefig("met_hist.png")
    plt.close()

    plt.figure()
    plt.hist(lepton_pt_list, bins=40, range=(0, 200), density=True)
    plt.xlabel("Lepton pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("lepton_pt_hist.png")
    plt.close()

    plt.figure()
    plt.hist(jet1_pt_list, bins=40, range=(0, 200), density=True)
    plt.xlabel("Leading Jet pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("jet1_pt_hist.png")
    plt.close()

    plt.figure()
    plt.hist(jet2_pt_list, bins=40, range=(0, 200), density=True)
    plt.xlabel("Subleading Jet pT (GeV)")
    plt.ylabel("Density")
    plt.savefig("jet2_pt_hist.png")
    plt.close()

    plt.figure()
    plt.hist(delta_r_list, bins=40, range=(0, 5), density=True)
    plt.xlabel("Delta R between Jets")
    plt.ylabel("Density")
    plt.savefig("delta_r_hist.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_lep_met_list, bins=40, range=(-3.14, 3.14), density=True)
    plt.xlabel("Delta Phi (Lepton, MET)")
    plt.ylabel("Density")
    plt.savefig("delta_phi_lep_met_hist.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_lep_twojet_list, bins=40, range=(-3.14, 3.14), density=True)
    plt.xlabel("Delta Phi (Lepton, Two-Jet System)")
    plt.ylabel("Density")
    plt.savefig("delta_phi_lep_twojet_hist.png")
    plt.close()

    plt.figure()
    plt.hist(lepton_eta_list, bins=40, range=(-2.5, 2.5), density=True)
    plt.xlabel("Lepton Eta")
    plt.ylabel("Density")
    plt.savefig("lepton_eta_hist.png")
    plt.close()

    # Save CSV for MLP analysis
    import csv
    with open("mlp_input.csv", "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["mt", "dijet_mass", "met", "lepton_pt", "delta_r", "delta_phi_lep_twojet"])
        for i in range(len(mt_list)):
            writer.writerow([
                mt_list[i],
                dijet_mass_list[i],
                met_list[i],
                lepton_pt_list[i],
                delta_r_list[i],
                delta_phi_lep_twojet_list[i]
            ])

if __name__ == "__main__":
    main()
