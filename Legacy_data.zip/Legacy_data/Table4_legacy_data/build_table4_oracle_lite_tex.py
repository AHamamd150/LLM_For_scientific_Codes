#!/usr/bin/env python3
"""Regenerate compact LaTeX summary tables from the English Table 4 annotations.

Usage (from the directory containing the files):
  python3 build_table4_oracle_lite_tex.py

Only standard library is used. Counts are report-level; no category deduplication.
"""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SRC = HERE / 'table4_oracle_lite_compact_english.csv'
TEX = HERE / 'table4_oracle_lite_recount.tex'
SUM = HERE / 'table4_oracle_lite_recount_summary.csv'

MODELS = [
    ('qwen2.5-7b-instruct', 'Qwen2.5-7B'),
    ('qwen2.5-14b-instruct', 'Qwen2.5-14B'),
    ('qwen2.5-32b-instruct', 'Qwen2.5-32B'),
    ('qwen2.5-72b-instruct', 'Qwen2.5-72B'),
    ('llama-3.1-8b-instruct', 'Llama3.1-8B'),
    ('llama-3.3-70b-instruct', 'Llama3.3-70B'),
]
MODEL_NAMES = dict(MODELS)
CLASSES = ('Useful', 'Partially useful', 'Off-target')
CATEGORIES = [
    'W collection scope',
    'b-jet collection scope',
    'W candidate reuse',
    'Top candidate consistency',
    'Lepton definition',
    'Selection ordering',
    'Output timing',
    'MET consistency',
    'Other / no matching historical category',
]
CAT_NAMES = {
    'W collection scope': r'$W$ collection scope',
    'b-jet collection scope': r'$b$-jet collection scope',
    'W candidate reuse': r'$W$ candidate reuse',
    'Top candidate consistency': 'Top candidate consistency',
    'Lepton definition': 'Lepton definition',
    'Selection ordering': 'Selection ordering',
    'Output timing': 'Output timing',
    'MET consistency': 'MET consistency',
    'Other / no matching historical category': 'Other',
}

records = list(csv.DictReader(SRC.open(encoding='utf-8-sig', newline='')))
assert len(records) == 172, f'Expected 172 reported items, got {len(records)}'
model_counts = defaultdict(Counter)
category_counts = defaultdict(Counter)
run_numbers = defaultdict(set)
ids = set()
for row in records:
    ident = row['Model (run, item)']
    m = re.fullmatch(r'(.+?) \[run (\d+), #(\d+)\]', ident)
    assert m, f'Unrecognized ID: {ident}'
    model, run, item = m.group(1), int(m.group(2)), int(m.group(3))
    assert model in MODEL_NAMES, f'Unrecognized model: {model}'
    assert 1 <= run <= 10, (model, run)
    assert (model, run, item) not in ids, (model, run, item)
    ids.add((model, run, item))
    label = row['ChatGPT provisional annotation'].split(':', 1)[0].strip()
    assert label in CLASSES, f'Unrecognized label: {label}'
    cat = row['Response category']
    assert cat in CATEGORIES, cat
    model_counts[model][label] += 1
    category_counts[cat][label] += 1
    run_numbers[model].add(run)

assert all(len(run_numbers[m]) == 10 for m, _ in MODELS)
assert sum(sum(c.values()) for c in model_counts.values()) == len(records)
assert sum(sum(c.values()) for c in category_counts.values()) == len(records)

def line(*cols):
    return ' & '.join(map(str, cols)) + r' \\'

def model_table():
    out = [
        r'% Table 4 replacement: counts of reported outputs, not per-run success probabilities.',
        r'\begin{table}[t]',
        r'\centering',
        r'\setlength{\tabcolsep}{6pt}',
        r'\begin{tabular}{lrrrrr}',
        r'\toprule',
        line('Model', 'Useful', 'Partially useful', 'Off-target', 'No report', 'Reported'),
        r'\midrule',
    ]
    totals = Counter()
    for i, (model, name) in enumerate(MODELS):
        if i == 4:
            out.append(r'\midrule')
        c = model_counts[model]
        reported = sum(c.values())
        no_report = 30 - reported
        assert no_report >= 0
        out.append(line(name, *(c[x] for x in CLASSES), no_report, reported))
        for x in CLASSES: totals[x] += c[x]
        totals['No report'] += no_report
        totals['Reported'] += reported
    out.extend([
        r'\midrule',
        line('Total', *(totals[x] for x in CLASSES), totals['No report'], totals['Reported']),
        r'\bottomrule',
        r'\end{tabular}',
        (r'\caption{Provisional classification of the legacy free-form oracle-lite outputs '
         r'on the original Case 2 task card. Each model was run ten times, with at most '
         r'three ambiguity reports per run. Useful reports pose a well-formed clarification '
         r'about an unresolved implementation choice; partially useful reports identify a '
         r'relevant implementation distinction but have an incomplete or imperfect '
         r'clarification or ask about a choice already specified by the task card. '
         r'Off-target reports do not provide a useful implementation distinction. '
         r'No report counts unfilled output slots, rather than incorrect responses. '
         r'These classifications are preliminary and require human adjudication.}'),
        r'\label{tab:legacy_oracle_lite_recount}',
        r'\end{table}',
    ])
    return '\n'.join(out)

def category_table():
    out = [
        r'% Optional companion table: issue-type totals across all models.',
        r'\begin{table}[t]',
        r'\centering',
        r'\setlength{\tabcolsep}{7pt}',
        r'\begin{tabular}{lrrrr}',
        r'\toprule',
        line('Reported issue category', 'Useful', 'Partially useful', 'Off-target', 'Total'),
        r'\midrule',
    ]
    totals = Counter()
    for cat in CATEGORIES:
        c = category_counts[cat]
        count = sum(c.values())
        out.append(line(CAT_NAMES[cat], *(c[x] for x in CLASSES), count))
        for x in CLASSES: totals[x] += c[x]
    out += [
        r'\midrule',
        line('Total', *(totals[x] for x in CLASSES), sum(totals.values())),
        r'\bottomrule',
        r'\end{tabular}',
        (r'\caption{Provisional issue-category breakdown of the 172 legacy oracle-lite '
         r'reports, pooled across all six models. These are report-level counts; '
         r'categories are assigned for analysis and should not be interpreted as '
         r'distinct task-card ambiguities. The Other category contains reports not '
         r'covered by the original eight categories.}'),
        r'\label{tab:legacy_oracle_lite_categories}',
        r'\end{table}',
    ]
    return '\n'.join(out)

paragraph = (r'''
% Optional replacement text for Section 4.4; edit after human review.
The legacy free-form oracle-lite experiment on the original Case~2 task card
produced 172 ambiguity reports across 60 runs, out of a maximum of 180.
To distinguish the recognition of implementation-sensitive choices from the
ability to formulate actionable clarification questions, we provisionally
classified each report as useful, partially useful, or off-target
(Table~\ref{tab:legacy_oracle_lite_recount}).
The preliminary classification gives 38 useful, 79 partially useful, and 55
off-target reports, with eight output slots left unfilled.
For Qwen2.5-32B, only two reports were classified as useful while 17 were
partially useful; for Qwen2.5-72B, the corresponding counts were 17 and six.
This contrast suggests that recognizing a potentially consequential choice and
expressing it as a well-posed clarification question are distinct challenges.
These provisional judgments are not directly comparable with the earlier
binary useful/off-target scores, and should be finalized through expert review.
''').strip()
TEX.write_text(model_table()+'\n\n'+category_table()+'\n\n'+paragraph+'\n', encoding='utf-8')

with SUM.open('w', encoding='utf-8', newline='') as h:
    w = csv.writer(h)
    w.writerow(['model','runs','useful','partially_useful','off_target','no_report','reported'])
    for model, name in MODELS:
        c = model_counts[model]
        n = sum(c.values())
        w.writerow([name,10,c['Useful'],c['Partially useful'],c['Off-target'],30-n,n])
    w.writerow(['Total',60,*[sum(model_counts[m][x] for m, _ in MODELS) for x in CLASSES], 180-len(records), len(records)])

print('Wrote:',TEX)
print('Wrote:',SUM)
for model,name in MODELS:
    c = model_counts[model]
    print(name, [c[x] for x in CLASSES], 30-sum(c.values()))
