#!/usr/bin/env python
import sys
import math
import numpy as np
import matplotlib.pyplot as plt

def read_lhco(filename):
    """Parse LHCO file and return list of events."""
    events = []
    current = None

    with open(filename) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            parts = line.split()
            if not parts:
                continue

            if parts[0] == '0':
                if len(parts) < 2:
                    continue
                try:
                    event_id = int(parts[1])
                except ValueError:
                    continue
                if current is not None:
                    events.append(current)
                current = {'id': event_id, 'objects': []}
            elif current is not None:
                if len(parts) < 7:
                    continue
                try:
                    obj = {
                        'type':   int(parts[1]),
                        'eta':    float(parts[2]),
                        'phi':    float(parts[3]),
                        'pt':     float(parts[4]),
                        'jmass':  float(parts[5]),
                        'ntrk':   float(parts[6]),
                        'btag':   float(parts[7]) if len(parts) > 7 else 0.0,
                        'had_em': float(parts[8]) if len(parts) > 8 else 0.0
                    }
                except ValueError:
                    continue

                obj['charge'] = 1 if obj['ntrk'] > 0 else (-1 if obj['ntrk'] < 0 else 0)
                current['objects'].append(obj)

    if current is not None:
        events.append(current)

    return events

def get_taus(event):
    """Return all taus."""
    return [o for o in event['objects'] if o['type'] == 3]

def get_jets(event):
    """Return all jets."""
    return [o for o in event['objects'] if o['type'] == 4]

def get_particle_mass(obj):
    """Return appropriate mass based on particle type."""
    if 'type' not in obj:
        return obj.get('mass', obj.get('jmass', 0.0))

    ptype = obj['type']
    if ptype == 0:    # photon
        return 0.0
    elif ptype == 1:  # electron
        return 0.0
    elif ptype == 2:  # muon
        return 0.0
    elif ptype == 3:  # tau
        return 1.777
    elif ptype == 4:  # jet
        return obj['jmass']
    else:
        return obj.get('mass', 0.0)

def four_momentum(obj):
    """Return (E, px, py, pz) from an object dict."""
    pt  = obj['pt']
    eta = obj['eta']
    phi = obj['phi']
    m   = get_particle_mass(obj)

    px = pt * math.cos(phi)
    py = pt * math.sin(phi)
    pz = pt * math.sinh(eta)
    E  = math.sqrt(px**2 + py**2 + pz**2 + m**2)
    return E, px, py, pz

def obj_from_four_momentum(E, px, py, pz):
    """
    Reconstruct a composite object dict from four-momentum (E, px, py, pz).
    Returns a dict with pt, eta, phi, and mass.
    """
    pt = math.sqrt(px**2 + py**2)
    phi = math.atan2(py, px)

    if pt > 0.0:
        eta = math.asinh(pz / pt)
    elif pz != 0.0:
        eta = math.copysign(float("inf"), pz)
    else:
        eta = 0.0

    p2 = px**2 + py**2 + pz**2
    m2 = E**2 - p2
    mass = math.sqrt(m2) if m2 > 0.0 else 0.0

    return {
        "pt": pt,
        "eta": eta,
        "phi": phi,
        "mass": mass
    }

def sum_objects(*args):
    """Return composite object from any combination of particles/lists."""
    particles = []
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            particles.append(arg)
        elif isinstance(arg, list):
            particles.extend(p for p in arg if p is not None)

    if not particles:
        return None

    E_tot, px_tot, py_tot, pz_tot = 0.0, 0.0, 0.0, 0.0
    for p in particles:
        E, px, py, pz = four_momentum(p)
        E_tot += E
        px_tot += px
        py_tot += py
        pz_tot += pz

    return obj_from_four_momentum(E_tot, px_tot, py_tot, pz_tot)

def helper_invariant_mass(*args):
    """Return invariant mass from any combination of particles/lists."""
    obj = sum_objects(*args)
    return obj['mass'] if obj is not None else 0.0

def helper_delta_eta(obj1, obj2):
    """Compute Δη between two objects."""
    return obj1['eta'] - obj2['eta']

def helper_get_leading(particles):
    """Return leading (highest pT) particle or None."""
    if not particles:
        return None
    return max(particles, key=lambda p: p['pt'])

def helper_get_subleading(particles):
    """Return subleading (second highest pT) particle or None."""
    if len(particles) < 2:
        return None
    sorted_p = sorted(particles, key=lambda p: p['pt'], reverse=True)
    return sorted_p[1]

def sort_by_pt(particles):
    """Return particles sorted by pT (descending)."""
    return sorted(particles, key=lambda p: p['pt'], reverse=True)

def opposite_sign(obj1, obj2):
    """Check if two objects have opposite charge."""
    return obj1['charge'] * obj2['charge'] < 0

def helper_delta_r(obj1, obj2):
    """Compute ΔR between two objects."""
    deta = abs(obj1['eta'] - obj2['eta'])
    dphi = abs(obj1['phi'] - obj2['phi'])
    if dphi > math.pi:
        dphi = 2 * math.pi - dphi
    return math.sqrt(deta**2 + dphi**2)

def helper_delta_phi(phi1, phi2):
    """Compute Δφ between two angles."""
    dphi = abs(phi1 - phi2)
    if dphi > math.pi:
        dphi = 2 * math.pi - dphi
    return dphi

def centrality_between_jets(obj, jet1, jet2):
    """
    Compute eta centrality of obj relative to two jets.

    centrality = |eta_obj - eta_center_jj| / |delta_eta_jj|
    Smaller values mean obj is closer to the midpoint between the two jets.
    """
    eta_gap = abs(jet1["eta"] - jet2["eta"])
    if eta_gap <= 0.0:
        return 0.0

    eta_center = 0.5 * (jet1["eta"] + jet2["eta"])
    return abs(obj["eta"] - eta_center) / eta_gap

def n_taus(event, pt_cut=20.0, eta_cut=2.3):
    """Count taus passing pT and |η| cuts."""
    taus = get_taus(event)
    return sum(1 for t in taus if t['pt'] > pt_cut and abs(t['eta']) < eta_cut)

def n_jets(event, pt_cut=30.0, eta_cut=4.7):
    """Count jets passing pT and |η| cuts."""
    jets = get_jets(event)
    return sum(1 for j in jets if j['pt'] > pt_cut and abs(j['eta']) < eta_cut)

def main():
    filename = sys.argv[1]
    events = read_lhco(filename)

    n_events = len(events)
    n_passing = n_events

    ditau_masses = []
    dijet_masses = []
    delta_eta_jets = []
    leading_tau_pt = []
    subleading_tau_pt = []
    leading_jet_pt = []
    subleading_jet_pt = []
    delta_r_taus = []
    delta_phi_systems = []
    centrality_dijet = []

    for event in events:
        taus = get_taus(event)
        jets = get_jets(event)

        # Select taus with pT > 20 GeV and |eta| < 2.3
        taus = [t for t in taus if t['pt'] > 20.0 and abs(t['eta']) < 2.3]
        if len(taus) < 2:
            n_passing -= 1
            continue

        # Define the leading and subleading taus
        leading_tau = helper_get_leading(taus)
        subleading_tau = helper_get_subleading(taus)
        if not leading_tau or not subleading_tau:
            n_passing -= 1
            continue

        # Build ditau system from the leading and subleading taus
        ditau_system = sum_objects(leading_tau, subleading_tau)
        ditau_mass = ditau_system['mass']
        if not 60.0 <= ditau_mass <= 150.0:
            n_passing -= 1
            continue

        # Select jets with pT > 30 GeV and |eta| < 4.7
        jets = [j for j in jets if j['pt'] > 30.0 and abs(j['eta']) < 4.7]
        if len(jets) < 2:
            n_passing -= 1
            continue

        # Define the leading and subleading jets
        leading_jet = helper_get_leading(jets)
        subleading_jet = helper_get_subleading(jets)
        if not leading_jet or not subleading_jet:
            n_passing -= 1
            continue

        # Build dijet system from the leading and subleading jets
        dijet_system = sum_objects(leading_jet, subleading_jet)
        dijet_mass = dijet_system['mass']
        if dijet_mass <= 400.0:
            n_passing -= 1
            continue

        # Require opposite-sign tau pair
        if not opposite_sign(leading_tau, subleading_tau):
            n_passing -= 1
            continue

        # Require |delta eta| between the two leading jets > 2.5
        delta_eta = abs(helper_delta_eta(leading_jet, subleading_jet))
        if delta_eta <= 2.5:
            n_passing -= 1
            continue

        # Veto events with b-tagged jets
        if any(j['btag'] == 1.0 for j in jets):
            n_passing -= 1
            continue

        # Collect values for plotting
        ditau_masses.append(ditau_mass)
        dijet_masses.append(dijet_mass)
        delta_eta_jets.append(delta_eta)
        leading_tau_pt.append(leading_tau['pt'])
        subleading_tau_pt.append(subleading_tau['pt'])
        leading_jet_pt.append(leading_jet['pt'])
        subleading_jet_pt.append(subleading_jet['pt'])
        delta_r_taus.append(helper_delta_r(leading_tau, subleading_tau))
        delta_phi_systems.append(helper_delta_phi(leading_tau['phi'], leading_jet['phi']))
        centrality_dijet.append(centrality_between_jets(ditau_system, leading_jet, subleading_jet))

    # Plot histograms
    plt.figure()
    plt.hist(ditau_masses, bins=40, range=(50, 160), density=True)
    plt.xlabel(r"$m_{\tau\tau}$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("ditau_mass.png")
    plt.close()

    plt.figure()
    plt.hist(dijet_masses, bins=40, range=(200, 2000), density=True)
    plt.xlabel(r"$m_{jj}$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("dijet_mass.png")
    plt.close()

    plt.figure()
    plt.hist(delta_eta_jets, bins=40, density=True)
    plt.xlabel(r"$|\Delta\eta_{jj}|$")
    plt.ylabel("Density")
    plt.savefig("delta_eta_jets.png")
    plt.close()

    plt.figure()
    plt.hist(leading_tau_pt, bins=40, density=True)
    plt.xlabel(r"$p_T(\tau_1)$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("leading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_tau_pt, bins=40, density=True)
    plt.xlabel(r"$p_T(\tau_2)$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("subleading_tau_pt.png")
    plt.close()

    plt.figure()
    plt.hist(leading_jet_pt, bins=40, density=True)
    plt.xlabel(r"$p_T(j_1)$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("leading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(subleading_jet_pt, bins=40, density=True)
    plt.xlabel(r"$p_T(j_2)$ [GeV]")
    plt.ylabel("Density")
    plt.savefig("subleading_jet_pt.png")
    plt.close()

    plt.figure()
    plt.hist(delta_r_taus, bins=40, density=True)
    plt.xlabel(r"$\Delta R(\tau_1, \tau_2)$")
    plt.ylabel("Density")
    plt.savefig("delta_r_taus.png")
    plt.close()

    plt.figure()
    plt.hist(delta_phi_systems, bins=40, density=True)
    plt.xlabel(r"$\Delta\phi(\tau\tau, jj)$")
    plt.ylabel("Density")
    plt.savefig("delta_phi_systems.png")
    plt.close()

    plt.figure()
    plt.hist(centrality_dijet, bins=40, density=True)
    plt.xlabel(r"Centrality($\tau\tau$)")
    plt.ylabel("Density")
    plt.savefig("centrality_dijet.png")
    plt.close()

    # Print cutflow summary
    print(f"Total events: {n_events}")
    print(f"Events passing all cuts: {n_passing}")

if __name__ == "__main__":
    main()