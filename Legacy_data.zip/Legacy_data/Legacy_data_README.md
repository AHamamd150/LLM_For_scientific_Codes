# Legacy experimental data

This directory preserves the historical experimental outputs used in the manuscript. The files are retained for provenance and inspection; they are not necessarily outputs from the current version of the workbench. Directory and file names inside the original run records have been preserved where practical.

## Contents

| Directory | Manuscript reference | Contents |
| --- | --- | --- |
| `Table2_legacy_data/` | Table 2 | Historical helper-selection runs for Qwen2.5-14B and Llama3-70B, summary files, the original run script, and `summarize_helper_selection_historical.py` for recounting helper-set stability. |
| `Table3_legacy_data/` | Table 3 | Representative Case 5 code-generation runs, grouped by helper selector (`sel-llama70B_run1/` and `sel-qwen14B_run1/`), with results for the two code-generation models under each selector. |
| `Table4_legacy_data/` | Table 4 | Historical `oracle-lite` outputs, the associated prompt, reviewed classifications and recount tables, and `build_table4_oracle_lite_tex.py`. |
| `Section_5.4_legacy_run/` | Tracer/Critique examples in the manuscript | Original `run_cfour7/` run records, including the Case 3 and Case 5 examples quoted in the text. |

## Notes on interpretation

- **Table 2:** The mandatory LHCO input parser, `read_lhco`, is excluded from the helper counts and pairwise Jaccard calculations in the recount. The script `summarize_helper_selection_historical.py` documents the calculation.
- **Table 3:** The four examples use the historical Case 5 task specification, rather than a subsequently revised task card. Model labels should be interpreted from the recorded runs; the 14B code-generation model in these historical examples is Qwen2.5-14B.
- **Table 4:** The preserved outputs were produced with the `oracle-lite` profile. The accompanying CSV and TeX files document the subsequent manual categorization and recount; they should not be mistaken for raw model output.
- **Tracer/Critique examples:** The quoted Case 3 and Case 5 findings are excerpts from the preserved historical runs. The Case 5 example analyzes generated code that did not execute successfully; it illustrates semantic inspection of the generated source, **not** detection of a silent error in a successfully executed analysis.

The historical records are provided to allow readers to inspect the evidence behind the reported examples and tables. They are not intended as a claim that all runs can be reproduced unchanged using the current workbench configuration.
